package com.poc.assignment.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.poc.assignment.model.Item;
import com.poc.assignment.repository.ItemRepository;

@ExtendWith(MockitoExtension.class)
class ItemServiceImplTest {

	@Mock
	ItemRepository itemRepo;

	@InjectMocks
	ItemServiceImpl itemService;

	@Test
	void testShowAllItems() {
		List<Item> itemList = new ArrayList<>();
		Item item = new Item(101, "Burgur", 10, 75, null);
		itemList.add(item);
		given(itemRepo.findAll()).willReturn(itemList);

		List<Item> newItemList = itemService.showAllItems();

		assertThat(newItemList).isNotEmpty();
		then(itemRepo).should().findAll();

	}

	@Test
	void testFindItem() {
		Item item = new Item(101, "Burgur", 10, 75, null);
		given(itemRepo.findOne(anyInt())).willReturn(item);

		Item newItem = itemService.findItem(101);

		assertEquals("Burgur", newItem.getItemName());
		then(itemRepo).should().findOne(anyInt());

	}

	@Test
	void testUpdateItem() {
		Item item= new Item(101, "Burgur", 10, 75, null);
		given(itemRepo.findOne(anyInt())).willReturn(item);
		
		Item newItem= itemService.findItem(101);
		given(itemRepo.save(newItem)).willReturn(newItem);

		String updateMessage = itemService.updateItem(101, newItem);

		assertEquals("Updated", updateMessage);
		then(itemRepo).should().save(newItem);
	}

	@Test
	void testAddItem() {
		Item item = new Item(101, "Burgur", 10, 75, null);
		given(itemRepo.save(item)).willReturn(item);

		String saveMessage = itemService.addItem(item);

		assertEquals("Saved", saveMessage);
		then(itemRepo).should().save(item);
	}

	@Test
	void testDeleteItem() {
		Item item = new Item(101, "Burgur", 10, 75, null);
		given(itemRepo.findOne(anyInt())).willReturn(item);

		Item newItem = itemService.findItem(101);
		itemService.deleteItem(newItem.getItemId());
		verify(itemRepo).delete(newItem);

	}

	@Test
	void testDeleteAllItem() {
		itemService.deleteAllItem();
		
		verify(itemRepo).deleteAll();
	}

}
