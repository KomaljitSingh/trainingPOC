package com.poc.assignment.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.poc.assignment.model.Bill;
import com.poc.assignment.model.Order;
import com.poc.assignment.repository.BillRepository;

@ExtendWith(MockitoExtension.class)
class BillServiceImplTest {

	@Mock
	BillRepository billRepository;
	
	@InjectMocks
	BillServiceImpl billService;
	
	
	@Test
	void testAddBill() {
		java.util.Date date=new java.util.Date();
		Order order=new Order();
		Bill bill =new Bill(101,125.2,date,order);
		given(billRepository.save(bill)).willReturn(bill);
		
		//When
		Bill newBill=billService.addBill(bill);
		
		assertThat(newBill).isEqualTo(bill);
		then(billRepository).should().save(bill);
	}

	@Test
	void testDeleteAllBill() {
	
		billService.deleteAllBill();
		verify(billRepository).deleteAll();
	}

	@Test
	void testDeleteBill() {
		Bill bill = new Bill();
		billService.deleteBill(bill.getBillNo());
		verify(billRepository).delete(bill.getBillNo());
	}

	@Test
	void testGetAllBill() {
		List<Bill> billList =new ArrayList<>();
		java.util.Date date=new java.util.Date();
		Order order=new Order();
		Bill bill =new Bill(101,125.2,date,order);
		billList.add(bill);
		given(billRepository.findAll()).willReturn(billList);
		
		//when
		List<Bill>  getList=billService.getAllBill();
		
		assertThat(getList).isNotEmpty();
		then(billRepository).should().findAll();
	}

	@Test
	void testFindBill() {
		java.util.Date date=new java.util.Date();
		Order order=new Order();
		Bill bill =new Bill(101,125.2,date,order);
		given(billRepository.findOne(anyInt())).willReturn(bill);
		
		Bill getBill =billService.findBill(101);
		
		assertEquals(101, getBill.getBillNo());
		assertEquals(125.2, getBill.getTotalAmount());
		then(billRepository).should().findOne(anyInt());
	}

}
