package com.poc.assignment.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.poc.assignment.model.CorporateCustomer;
import com.poc.assignment.model.Customer;
import com.poc.assignment.model.Order;
import com.poc.assignment.repository.CustomerRepository;

@ExtendWith(MockitoExtension.class)
class CustomerServiceImplTest {

	@Mock
	CustomerRepository custRepo;

	@InjectMocks
	CustomerServiceImpl custService;

	@Test
	void testAddCustomer() {
		Date dob = new Date();
		List<Order> orderList = new ArrayList<>();
		Customer cust = new CorporateCustomer(101, "Komal", dob, "c", "9988776655", "noida", orderList, 107846, 12);
		
		given(custRepo.save(cust)).willReturn(cust);

		String saveMessage = custService.addCustomer(cust);

		assertEquals("Saved", saveMessage);
		then(custRepo).should().save(cust);
	}

	@Test
	void testFindCustomer() {
		Date dob = new Date();
		List<Order> orderList = new ArrayList<>();
		Customer cust = new CorporateCustomer(101, "Komal", dob, "c", "9988776655", "noida", orderList, 107846, 12);
		given(custRepo.findOne(anyInt())).willReturn(cust);
		
		Customer newCust=custService.findCustomer(101);
		
		assertEquals("noida", newCust.getAddress());
		then(custRepo).should().findOne(anyInt());
		
			
	}

	@Test
	void testFindAll() {
		List<Customer> custList= new ArrayList<>();
		Date dob = new Date();
		List<Order> orderList = new ArrayList<>();
		Customer cust = new CorporateCustomer(101, "Komal", dob, "c", "9988776655", "noida", orderList, 107846, 12);
		custList.add(cust);
		
		given(custRepo.findAll()).willReturn(custList);
		
		List<Customer> newCustList=custService.findAll();
		
		assertThat(newCustList).isNotEmpty();
		then(custRepo).should().findAll();		
	}

}
