package com.poc.assignment.service;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.verify;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.poc.assignment.model.Order;import com.poc.assignment.repository.OrderRepository;

@ExtendWith(MockitoExtension.class)
class OrderServiceImplTest {

	@Mock
	OrderRepository orderRepo;
	@InjectMocks
	OrderServiceImpl orderService;
	
	@Test
	void testShowAllOrders() {
		List<Order> orderList =new ArrayList<>();
		Order order = new Order(101, null, null, null, null);
		orderList.add(order);
		given(orderRepo.findAll()).willReturn(orderList);
		
		List<Order> newOrderList= orderService.showAllOrders();
		
		assertThat(newOrderList).isNotEmpty();
		then(orderRepo).should().findAll();
		
		
		
	}

	@Test
	void testFindOrder() {
		Order order = new Order(101, null, null, null, null);
		given(orderRepo.findOne(anyInt())).willReturn(order);
		
		Order newOrder= orderService.findOrder(101);
		
		assertThat(newOrder).isNotNull();
		then(orderRepo).should().findOne(anyInt());
	}

	@Test
	void testAddOrder() {
		Order order = new Order(101, null, null, null, null);
		given(orderRepo.save(order)).willReturn(order);
		
		String orderMessage=orderService.addOrder(order);
		
		assertThat(orderMessage).isNotEmpty();
		then(orderRepo).should().save(order);
		
	}

	@Test
	void testDeleteOrder() {
		
	}

	@Test
	void testDeleteAllOrder() {
		
	}

}
