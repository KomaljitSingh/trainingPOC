package com.poc.assignment.service;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.poc.assignment.model.CorporateCustomer;
import com.poc.assignment.model.Order;
import com.poc.assignment.repository.CorpCustomerRepository;

@ExtendWith(MockitoExtension.class)
class CorpCustomerServiceImplTest {

	@Mock
	CorpCustomerRepository corpCustRepo;

	@InjectMocks
	CorpCustomerServiceImpl corpCustService;

	@Test
	void testAddCorpCustomer() {
		Date dob = new Date();
		List<Order> orderList = new ArrayList<>();
		CorporateCustomer corpCust = new CorporateCustomer(101, "Komal", dob, "c", "9988776655", "noida", orderList,
				107846, 12);

		given(corpCustRepo.save(corpCust)).willReturn(corpCust);

		String saveMessage = corpCustService.addCorpCustomer(corpCust);

		assertEquals("Saved", saveMessage);
		then(corpCustRepo).should().save(corpCust);
	}

	@Test
	void testFindCustomer() {
		Date dob = new Date();
		List<Order> orderList = new ArrayList<>();
		CorporateCustomer corpCust = new CorporateCustomer(101, "Komal", dob, "c", "9988776655", "noida", orderList,
				107846, 12);
		given(corpCustRepo.findOne(anyInt())).willReturn(corpCust);
		
		CorporateCustomer newCorpCust=corpCustService.findCustomer(101);
		
		assertEquals("Komal", newCorpCust.getCustName());
		then(corpCustRepo).should().findOne(anyInt());
	}

	@Test
	void testFindAll() {

		List<CorporateCustomer> corpCustList = new ArrayList<>();
		Date dob = new Date();
		List<Order> orderList = new ArrayList<>();
		CorporateCustomer corpCust = new CorporateCustomer(101, "Komal", dob, "c", "9988776655", "noida", orderList,
				107846, 12);
		corpCustList.add(corpCust);
		given(corpCustRepo.findAll()).willReturn(corpCustList);
		
		List<CorporateCustomer> newCorpCustList =corpCustService.findAll();
		
		assertThat(newCorpCustList).isNotEmpty();
		then(corpCustRepo).should().findAll();
	}

}
