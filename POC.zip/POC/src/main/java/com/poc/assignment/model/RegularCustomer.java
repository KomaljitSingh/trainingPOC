package com.poc.assignment.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonTypeName;

@Entity
@Table(name = "RegCustomer")
@JsonTypeName("regularCustomer")
public class RegularCustomer extends Customer {

	@Column
	public int customerPoints;

	public int getCustomerPoints() {
		return customerPoints;
	}

	public void setCustomerPoints(int customerPoints) {
		this.customerPoints = customerPoints;
	}

	public RegularCustomer() {
		super();

	}

	public RegularCustomer(int custId, String custName, Date custDOB, String mobile, String custType, String address,
			List<Order> order) {
		super(custId, custName, custDOB, mobile, custType, address, order);

	}

	public RegularCustomer(int custId, String custName, Date custDOB, String mobile, String custType, String address,
			List<Order> order, int customerPoints) {
		super(custId, custName, custDOB, mobile, custType, address, order);
		this.customerPoints = customerPoints;
	}

	@Override
	public String toString() {
		return "RegularCustomer [customerPoints=" + customerPoints + "]";
	}

}
