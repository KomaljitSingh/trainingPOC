package com.poc.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.poc.assignment.model.Item;
import com.poc.assignment.model.Order;
import com.poc.assignment.service.RestaurantServiceImpl;

@RestController
@RequestMapping("Restaurant")
public class RestaurantController {

	@Autowired
	RestaurantServiceImpl restService;

	@GetMapping(value = "Menu")
	public List<Item> showMenu() {
		return restService.showMenu();
	}

	@PostMapping(value = "takeOrder")
	public String takeOrder(@RequestBody Order order) {
		return restService.takeOrder(order);
	}

	@GetMapping(value = "ShowOfferRegular/{custId}")
	public String showRegCustomerOffer(@PathVariable(value = "custId") int custId) {

		return restService.showRegCustomerOffer(custId);
	}

	@GetMapping(value = "ShowOfferCorporate/{custId}")
	public String showCorpCustomerOffer(@PathVariable(value = "custId") int custId) {

		return restService.showCorpCustomerOffer(custId);
	}

	@GetMapping(value = "checkStatus/{orderId}")
	public String checkStatus(@PathVariable(value = "orderId") int orderId) {
		return restService.checkStatus(orderId);
	}

}
