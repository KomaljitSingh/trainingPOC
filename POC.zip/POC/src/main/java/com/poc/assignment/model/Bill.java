package com.poc.assignment.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Bill")
public class Bill {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int billNo;
	@Column
	private double totalAmount;
	@Column
	private Date dateOfOrder;
	@OneToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "orderId", nullable = false)
	private Order order;

	public int getBillNo() {
		return billNo;
	}

	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Date getDateOfOrder() {
		return dateOfOrder;
	}

	public void setDateOfOrder(Date dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}

	public Bill(int billNo, double totalAmount, Date dateOfOrder, Order order) {
		super();
		this.billNo = billNo;
		this.totalAmount = totalAmount;
		this.dateOfOrder = dateOfOrder;
		this.order = order;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Bill() {
		super();
		// TODO Auto-generated constructor stub
	}

}
