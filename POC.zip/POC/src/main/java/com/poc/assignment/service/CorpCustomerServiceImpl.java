package com.poc.assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poc.assignment.model.CorporateCustomer;

import com.poc.assignment.repository.CorpCustomerRepository;

@Service
public class CorpCustomerServiceImpl implements CorpCustomerService {

	@Autowired
	CorpCustomerRepository corpCustRepo;

	@Override
	public String addCorpCustomer(CorporateCustomer corpCust) {
		// TODO Auto-generated method stub
		corpCustRepo.save(corpCust);
		return "Saved";
	}

	@Override
	public CorporateCustomer findCustomer(int id) {
		// TODO Auto-generated method stub
		return corpCustRepo.findOne(id);
	}

	@Override
	public List<CorporateCustomer> findAll() {
		// TODO Auto-generated method stub
		return corpCustRepo.findAll();
	}

}
