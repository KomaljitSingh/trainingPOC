package com.poc.assignment.service;

import java.util.List;

import com.poc.assignment.model.CorporateCustomer;

public interface CorpCustomerService {

	public String addCorpCustomer(CorporateCustomer corpCust);

	public CorporateCustomer findCustomer(int id);

	public List<CorporateCustomer> findAll();

}