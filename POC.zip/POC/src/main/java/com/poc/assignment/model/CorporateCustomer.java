package com.poc.assignment.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonTypeName;

@Entity
@Table(name = "CorpCustomer")
@JsonTypeName("corporateCustomer")
public class CorporateCustomer extends Customer {

	@Column
	public int regNo;
	@Column
	public double discountPercent;

	public int getRegNo() {
		return regNo;
	}

	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}

	public double getDiscountPercent() {
		return discountPercent;
	}

	public void setDiscountPercent(double discountPercent) {
		this.discountPercent = discountPercent;
	}

	public CorporateCustomer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CorporateCustomer(int custId, String custName, Date custDOB, String mobile, String custType, String address,
			List<Order> order, int regNo, double discountPercent) {
		super(custId, custName, custDOB, mobile, custType, address, order);
		this.regNo = regNo;
		this.discountPercent = discountPercent;
	}

	public CorporateCustomer(int custId, String custName, Date custDOB, String mobile, String custType, String address,
			List<Order> order) {
		super(custId, custName, custDOB, mobile, custType, address, order);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "CorporateCustomer [regNo=" + regNo + ", discountPercent=" + discountPercent + "]";
	}

}
