package com.poc.assignment.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NaturalIdCache;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "ORDERNEW1")
@EntityListeners({ AuditingEntityListener.class })
@NaturalIdCache

public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private int orderId;
	@CreatedDate
	@Column
	private Date orderDate;

	@ManyToMany()
	@JoinColumn(name = "orderId", referencedColumnName = "itemId")
	private List<Item> item;

	@ManyToOne()
	@JoinColumn(name = "custId")
	private Customer customer;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "order")
	private Bill bill;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Order(int orderId, Date orderDate, List<Item> item, Customer customer, Bill bill) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.item = item;
		this.customer = customer;
		this.bill = bill;
	}

	public Bill getBill() {
		return bill;
	}

	public void setBill(Bill bill) {
		this.bill = bill;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Item> getItem() {
		return item;
	}

	public void setItem(List<Item> item) {
		this.item = item;
	}

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

}
