package com.poc.assignment.service;

import java.util.List;

import com.poc.assignment.model.Item;
import com.poc.assignment.model.Order;

public interface RestaurantService {

	public List<Item> showMenu();

	public String takeOrder(Order order);

	public String checkStatus(int orderId);

	public String showRegCustomerOffer(int custId);

	public String showCorpCustomerOffer(int corpId);

}
