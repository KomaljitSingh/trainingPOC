package com.poc.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.poc.assignment.model.CorporateCustomer;
import com.poc.assignment.model.RegularCustomer;
import com.poc.assignment.service.CorpCustomerServiceImpl;
import com.poc.assignment.service.RegCustomerServiceImpl;

@RestController
@RequestMapping("Customer")
public class CustomerController {
	@Autowired
	RegCustomerServiceImpl regCustService;

	@Autowired
	CorpCustomerServiceImpl corpCustService;

	@PostMapping(value = "addRegCust")
	public RegularCustomer addRegCustomer(@RequestBody RegularCustomer regCust) {
		System.out.println(regCust);
		return regCustService.addRegCustomer(regCust);

	}

	@PostMapping(value = "addCorpCust")
	public String addCorpCustomer(@RequestBody CorporateCustomer corpCust) {
		System.out.println(corpCust);
		return corpCustService.addCorpCustomer(corpCust);

	}

	@GetMapping(value = "findRegCust/{id}")
	public RegularCustomer findRCust(@PathVariable(value = "id") int id) {
		return regCustService.findCustomer(id);
	}

	@GetMapping(value = "findCorpCust/{id}")
	public CorporateCustomer findCCust(@PathVariable(value = "id") int id) {
		return corpCustService.findCustomer(id);
	}

	@GetMapping(value = "findR")
	public List<RegularCustomer> findRAll() {
		return regCustService.findAll();
	}

	@GetMapping(value = "findC")
	public List<CorporateCustomer> findCAll() {
		return corpCustService.findAll();
	}
}
