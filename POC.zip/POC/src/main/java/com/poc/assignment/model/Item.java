package com.poc.assignment.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name = "ITEMNEW1")
public class Item {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int itemId;
	@Column
	private String itemName;
	@Column
	private int itemPrepTime;
	@Column
	private double itemPrice;
	@ManyToMany(mappedBy = "item", fetch = FetchType.LAZY)
	@NotFound(action = NotFoundAction.IGNORE)

	private List<Order> order;

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getItemPrepTime() {
		return itemPrepTime;
	}

	public void setItemPrepTime(int itemPrepTime) {
		this.itemPrepTime = itemPrepTime;
	}

	public double getPrice() {
		return itemPrice;
	}

	public void setPrice(double price) {
		this.itemPrice = price;
	}

	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemName=" + itemName + ", itemPrepTime=" + itemPrepTime + ", itemPrice="
				+ itemPrice + "]";
	}

	public Item(int itemId, String itemName, int itemPrepTime, double itemPrice, List<Order> order) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrepTime = itemPrepTime;
		this.itemPrice = itemPrice;
		this.order = order;
	}

	public List<Order> getOrder() {
		return order;
	}

	public void setOrder(List<Order> order) {
		this.order = order;
	}

}
