package com.poc.assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poc.assignment.model.RegularCustomer;
import com.poc.assignment.repository.RegCustomerRepositroy;

@Service
public class RegCustomerServiceImpl implements RegCustomerService {

	@Autowired
	RegCustomerRepositroy regCustRepo;

	@Override
	public RegularCustomer addRegCustomer(RegularCustomer regCust) {
		// TODO Auto-generated method stub

		return regCustRepo.save(regCust);
	}

	@Override
	public RegularCustomer findCustomer(int id) {
		// TODO Auto-generated method stub
		return regCustRepo.findOne(id);
	}

	@Override
	public List<RegularCustomer> findAll() {
		// TODO Auto-generated method stub
		return regCustRepo.findAll();
	}

}
