package com.poc.assignment.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeId;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@Entity
@Table(name = "CustomerRes")

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")

@JsonSubTypes({ @JsonSubTypes.Type(value = RegularCustomer.class, name = "regularCustomer"),
		@JsonSubTypes.Type(value = CorporateCustomer.class, name = "corporateCustomer") })

public abstract class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@JsonTypeId
	public int custId;
	@Column
	public String custName;
	@Column
	public Date custDOB;
	@Column
	public String mobile;
	@Column
	public String custType;
	@Column
	public String address;

	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
	@NotFound(action = NotFoundAction.IGNORE)
	public List<Order> order;

	public Customer(int custId, String custName, Date custDOB, String mobile, String custType, String address,
			List<Order> order) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custDOB = custDOB;
		this.mobile = mobile;
		this.custType = custType;
		this.address = address;
		this.order = order;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public Date getCustDOB() {
		return custDOB;
	}

	public void setCustDOB(Date custDOB) {
		this.custDOB = custDOB;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<Order> getOrder() {
		return order;
	}

	public void setOrder(List<Order> order) {
		this.order = order;
	}

}
