package com.poc.assignment.service;

import java.util.List;

import com.poc.assignment.model.Item;

public interface ItemService {

	public List<Item> showAllItems();

	public Item findItem(int itemId);

	public String updateItem(int id, Item item);

	public String addItem(Item item);

	public String deleteItem(int id);

	public String deleteAllItem();

}
