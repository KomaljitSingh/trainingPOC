package com.poc.assignment.service;

import java.util.List;

import com.poc.assignment.model.Order;

public interface OrderService {

	public List<Order> showAllOrders();

	public Order findOrder(int orderId);

	public String addOrder(Order order);

	public String deleteOrder(int id);

	public String deleteAllOrder();
}
