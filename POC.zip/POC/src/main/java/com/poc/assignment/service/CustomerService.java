package com.poc.assignment.service;

import java.util.List;

import com.poc.assignment.model.Customer;

public interface CustomerService {

	public String addCustomer(Customer cust);

	public Customer findCustomer(int id);

	public List<Customer> findAll();

}