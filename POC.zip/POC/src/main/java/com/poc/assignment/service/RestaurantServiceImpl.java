package com.poc.assignment.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poc.assignment.model.CorporateCustomer;
import com.poc.assignment.model.Item;
import com.poc.assignment.model.Order;
import com.poc.assignment.model.RegularCustomer;

@Service
public class RestaurantServiceImpl implements RestaurantService {

	@Autowired
	RegCustomerServiceImpl regService;
	@Autowired
	CorpCustomerService corpService;
	@Autowired
	ItemServiceImpl itemService;
	@Autowired
	OrderServiceImpl orderSerivce;

	@Override
	public List<Item> showMenu() {

		return itemService.showAllItems();

	}

	@Override
	public String takeOrder(Order order) {

		return orderSerivce.addOrder(order);

	}

	@Override
	public String checkStatus(int orderId) {
		Order order = orderSerivce.findOrder(orderId);
		List<Item> itemList = order.getItem();
		List<Integer> timeList = new ArrayList<>();
		for (Item item : itemList) {
			timeList.add(item.getItemPrepTime());
		}

		// Fetching max time from list of items
		int maxTime = Collections.max(timeList);

		// Fetching current time and setting order time
		Calendar orderTime = Calendar.getInstance();
		orderTime.setTime(order.getOrderDate());

		// When time is set to orderTime then add max time
		orderTime.add(Calendar.MINUTE, (maxTime));

		Calendar currentTime = Calendar.getInstance();

		if (orderTime.after(currentTime)) {

			return "Order Preparing";
		}
		return "Ready";

	}

	@Override
	public String showRegCustomerOffer(int custId) {
		RegularCustomer regCust = regService.findCustomer(custId);
		int points = regCust.getCustomerPoints();
		return "Your Points are " + Integer.toString(points);

	}

	@Override
	public String showCorpCustomerOffer(int corpId) {
		CorporateCustomer corpCust = corpService.findCustomer(corpId);
		double discount = corpCust.getDiscountPercent();
		return "Your have " + Double.toString(discount) + "% discount on min order of 1000";

	}

}
