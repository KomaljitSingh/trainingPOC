package com.poc.assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poc.assignment.model.Item;
import com.poc.assignment.repository.ItemRepository;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	ItemRepository itemRepository;

	@Override
	public List<Item> showAllItems() {
		// TODO Auto-generated method stub
		return itemRepository.findAll();
	}

	@Override
	public Item findItem(int itemId) {

		return itemRepository.findOne(itemId);
	}

	@Override
	public String updateItem(int id, Item item) {
		Item foundItem = itemRepository.findOne(id);
		foundItem.setPrice(item.getPrice());
		itemRepository.save(foundItem);
		
		return "Updated";
	}

	@Override
	public String addItem(Item item) {
		itemRepository.save(item);
		return "Saved";
	}

	@Override
	public String deleteItem(int id) {
		Item foundItem = itemRepository.findOne(id);
		itemRepository.delete(foundItem);
		return "Item deleted of Item Id:-" + id;
	}

	@Override
	public String deleteAllItem() {
		itemRepository.deleteAll();
		return "Deleted All";
	}

}
