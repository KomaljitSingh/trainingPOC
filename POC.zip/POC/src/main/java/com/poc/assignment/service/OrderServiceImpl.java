package com.poc.assignment.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poc.assignment.model.Bill;
import com.poc.assignment.model.Item;
import com.poc.assignment.model.Order;
import com.poc.assignment.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderRepository orderRepository;
	@Autowired
	BillServiceImpl billService;
	@Autowired
	ItemServiceImpl itemService;
	@Autowired
	CustomerServiceImpl custSer;

	@Override
	public List<Order> showAllOrders() {
		
		return orderRepository.findAll();
	}

	@Override
	public Order findOrder(int orderId) {
		
		return orderRepository.findOne(orderId);
	}

	@Override
	public String addOrder(Order order) {

		Order newOrder = orderRepository.save(order);
		String displayMessage=addBill(newOrder);
			return displayMessage;
	}
	

	@Override
	public String deleteOrder(int id) {
		
		Order foundOrder = orderRepository.findOne(id);
		orderRepository.delete(foundOrder);
		return "Item deleted of Item Id:-" + id;
	}

	@Override
	public String deleteAllOrder() {
		
		orderRepository.deleteAll();
		return "Deleted All";
	}

	public String addBill(Order newOrder)
	{
		Bill bill = new Bill();
		bill.setDateOfOrder(newOrder.getOrderDate());
		bill.setOrder(newOrder);
		List<Item> orderItems = newOrder.getItem();
		System.out.println(orderItems);
		double totalAmount = 0;
		List<Integer> timeList = new ArrayList<>();
		for (Item item : orderItems) {
			Item newItem = itemService.findItem(item.getItemId());

			totalAmount += newItem.getPrice();
			timeList.add(newItem.getItemPrepTime());

		}

		// Fetching max time from list of items
		int maxTime = Collections.max(timeList);
		
		bill.setTotalAmount(totalAmount);
		billService.addBill(bill);
		String displayMessage="********************** \n Your order Id is "+newOrder.getOrderId()+"\n It will take "+maxTime+" mins \n Your bill is"+totalAmount+"\n**********************";
		return displayMessage;
	}
}
