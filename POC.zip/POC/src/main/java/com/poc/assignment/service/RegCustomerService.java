package com.poc.assignment.service;

import java.util.List;

import com.poc.assignment.model.RegularCustomer;

public interface RegCustomerService {

	public RegularCustomer addRegCustomer(RegularCustomer regCust);

	public RegularCustomer findCustomer(int id);

	public List<RegularCustomer> findAll();

}
