package com.poc.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.poc.assignment.model.Order;

import com.poc.assignment.service.OrderServiceImpl;

@RestController
@RequestMapping("Order")
public class OrderController {

	@Autowired
	OrderServiceImpl orderService;

	@GetMapping(value = "Orders")
	public List<Order> showAll() {
		return orderService.showAllOrders();
	}

	@GetMapping(value = "findItem/{orderId}")
	public Order findOrder(@PathVariable(value = "orderId") int orderId) {
		return orderService.findOrder(orderId);

	}

	@PostMapping(value = "addOrder")
	public String addOrder(@RequestBody Order order) {
		return orderService.addOrder(order);
	}

	@DeleteMapping(value = "deleteOrder/{orderId}")
	public String deleteItem(@PathVariable(value = "orderId") int orderId) {
		return orderService.deleteOrder(orderId);
	}

	@DeleteMapping(value = "delete")
	public String deleteAll() {
		return orderService.deleteAllOrder();
	}
}
