package com.poc.assignment.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.poc.assignment.model.Item;
import com.poc.assignment.service.ItemServiceImpl;

@RestController
@RequestMapping("Item")
public class ItemController {

	@Autowired
	ItemServiceImpl itemService;

	@GetMapping(value = "Items")
	public List<Item> showAll() {
		return itemService.showAllItems();
	}

	@GetMapping(value = "findItem/{itemId}")
	public Item findItem(@PathVariable(value = "itemId") int itemId) {
		return itemService.findItem(itemId);

	}

	@PutMapping(value = "updateItem/{itemId}")
	public String updateItem(@Valid @RequestBody Item item, @PathVariable(value = "itemId") int itemId) {
		return itemService.updateItem(itemId, item);
	}

	@PostMapping(value = "addItem")
	public String addItem(@RequestBody Item item) {
		return itemService.addItem(item);
	}

	@DeleteMapping(value = "deleteItem/{itemId}")
	public String deleteItem(@PathVariable(value = "itemId") int itemId) {
		return itemService.deleteItem(itemId);
	}

	@DeleteMapping(value = "delete")
	public String deleteAll() {
		return itemService.deleteAllItem();
	}
}
