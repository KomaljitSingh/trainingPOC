package com.poc.assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poc.assignment.model.Bill;
import com.poc.assignment.repository.BillRepository;

@Service
public class BillServiceImpl implements BillService {

	@Autowired
	BillRepository billRepo;

	@Override
	public Bill addBill(Bill bill) {
		// TODO Auto-generated method stub
		return billRepo.save(bill);
	}

	@Override
	public String deleteAllBill() {
		// TODO Auto-generated method stub1
		billRepo.deleteAll();
		return "AllDeleted";
	}

	@Override
	public String deleteBill(int id) {
		// TODO Auto-generated method stub
		billRepo.delete(id);
		return "Deleted";
	}

	@Override
	public List<Bill> getAllBill() {
		// TODO Auto-generated method stub
		return billRepo.findAll();
	}

	@Override
	public Bill findBill(int id) {
		// TODO Auto-generated method stub
		return billRepo.findOne(id);
	}

}
