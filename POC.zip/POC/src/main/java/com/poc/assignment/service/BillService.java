package com.poc.assignment.service;

import java.util.List;

import com.poc.assignment.model.Bill;

public interface BillService {

	public Bill addBill(Bill bill);

	public String deleteAllBill();

	public String deleteBill(int id);

	public List<Bill> getAllBill();

	public Bill findBill(int id);
}
