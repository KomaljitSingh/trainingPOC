package com.poc.assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poc.assignment.model.Customer;
import com.poc.assignment.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository custRepo;

	@Override
	public String addCustomer(Customer cust) {
		// TODO Auto-generated method stub
		custRepo.save(cust);
		return "Saved";
	}

	@Override
	public Customer findCustomer(int id) {
		// TODO Auto-generated method stub
		return custRepo.findOne(id);
	}

	@Override
	public List<Customer> findAll() {
		// TODO Auto-generated method stub
		return custRepo.findAll();
	}

}
